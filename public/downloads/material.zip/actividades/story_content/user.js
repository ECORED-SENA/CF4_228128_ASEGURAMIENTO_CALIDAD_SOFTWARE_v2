function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5kDLOrP1Rw5":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

